package com.example.jarvis

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import okhttp3.*
import org.json.JSONObject
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private val client = OkHttpClient()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var output: TextView
    private val apiKey = BuildConfig.OPENAI_API_KEY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout_main())

        output = findViewById(1002)
        findViewById<Button>(1001).setOnClickListener { listen() }
    }

    private fun layout_main(): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 60, 36, 36)
            setBackgroundColor(android.graphics.Color.rgb(7,17,31))
        }
        val title = TextView(this).apply {
            text = "J A R V I S"
            textSize = 30f
            setTextColor(android.graphics.Color.WHITE)
        }
        output = TextView(this).apply {
            id = 1002
            text = "Olá. Estou pronto."
            textSize = 18f
            setTextColor(android.graphics.Color.LTGRAY)
            setPadding(0, 50, 0, 50)
        }
        val button = Button(this).apply {
            id = 1001
            text = "🎙 FALAR COM JARVIS"
        }
        box.addView(title); box.addView(output)
        box.addView(button, LinearLayout.LayoutParams(-1, 70))
        return box
    }

    private fun listen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale("pt", "BR"))
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Fale com o Jarvis")
        }
        startActivityForResult(intent, 20)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 20 && resultCode == Activity.RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull() ?: return
            output.text = "Você: $text\n\nJARVIS está pensando..."
            askOpenAI(text)
        }
    }

    private fun askOpenAI(text: String) {
        if (apiKey.isBlank()) {
            output.text = "Configure OPENAI_API_KEY no Gradle antes de usar."
            return
        }
        scope.launch(Dispatchers.IO) {
            try {
                val body = JSONObject().apply {
                    put("model", "gpt-5-mini")
                    put("input", "Você é JARVIS, um assistente pessoal em português do Brasil. Seja objetivo e natural. Usuário: $text")
                }.toString()
                val request = Request.Builder()
                    .url("https://api.openai.com/v1/responses")
                    .addHeader("Authorization", "Bearer $apiKey")
                    .addHeader("Content-Type", "application/json")
                    .post(body.toRequestBody("application/json".toMediaType()))
                    .build()
                val response = client.newCall(request).execute()
                val json = JSONObject(response.body?.string() ?: "{}")
                val answer = json.optString("output_text", "Não consegui responder agora.")
                withContext(Dispatchers.Main) {
                    output.text = "Você: $text\n\nJARVIS: $answer"
                    android.speech.tts.TextToSpeech(this@MainActivity, null).speak(
                        answer, android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, "jarvis"
                    )
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { output.text = "Erro: ${e.message}" }
            }
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }
}
